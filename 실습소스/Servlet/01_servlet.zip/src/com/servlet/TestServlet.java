package com.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// 요청 URL: http://localhost:8090/01_servlet(context명)/test(매핑명)
@WebServlet("/test")
public class TestServlet extends HttpServlet {

	
	@Override
	public void destroy() {
		System.out.println("TestServlet.destroy");
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("TestServlet.init");
   } // servlet은 한 번만 생성 (즉 init은 한 번만 출력)

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// 이후 서버 요청할 때마다 doGet만 출력
		
		// 웹 브라우저가 아닌 Tomcat서버의 콘솔에 출력됨
		System.out.println("TestServlet.doGet");
		
		
	}

}
