package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//요청 URL: http://localhost:8090/01_servlet/login
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	
	protected void doGet(HttpServletRequest request, 
						 HttpServletResponse response) 
			throws ServletException, IOException {
	
		System.out.println("LoginServlet.doGet");
		
	// 사용자 입력 데이터 얻기 
		// 메서드 이용 String s = request.getParameter("tag의 name값");
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		String xxx = request.getParameter("address"); // 없는 파라미터 요청하면 null 나옴
		
		System.out.println(userid + "\t" + passwd);
		// 결과값: 1111	aaaa (로그인폼 html에서 사용자가 입력한 데이터 반환)
	}
	
	
protected void doPost(HttpServletRequest request, 
				 HttpServletResponse response) 
	throws ServletException, IOException {
// post 방식은 한글이 깨져 나오기 때문에 한글처리 필수! 		
System.out.println("LoginServlet.doPost");
request.setCharacterEncoding("utf-8"); // <== post 한글처리
		
String userid = request.getParameter("userid");
String passwd = request.getParameter("passwd");
String xxx = request.getParameter("address"); // 없는 파라미터 요청하면 null 나옴

System.out.println(userid + "\t" + passwd);
	}
}
