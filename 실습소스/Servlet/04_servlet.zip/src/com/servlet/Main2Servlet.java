package com.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/main2")
public class Main2Servlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("Main2Servlet");
		// 요청 위임 방법 2 - 리다이렉트(redirect) (response 메서드 이용)
		
		// 세 가지 scope에 저장
				request.setAttribute("request", "request"); // request값 null 나옴 
				
				HttpSession session = request.getSession();
				session.setAttribute("session", "session");
				
				ServletContext applicaton = getServletContext();
				applicaton.setAttribute("applicaton", "applicaton");
				
		// URL이 변경됨 (~04_servlet/response 로 나옴)
		response.sendRedirect("response");
		// "response" 자리에는 response 서블릿의 매핑값이 들어감
		// redirect를 통해서 response 서블릿에 위임했기 때문에 출력은 main2이 아닌 response 서블릿이 출력됨
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
