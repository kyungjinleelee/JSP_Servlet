package com.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// 요청 서블릿
// http://localhost:8090/04_servlet/main
@WebServlet("/main")
public class MainServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("MainServlet");
		// 요청 위임 방법 1 - 포워드(forward) (HttpServletRequest 메서드 이용)
		// 가. URL 변경이 안됨. (계속 ~04_servlet/main 으로 남아있음) request가 확장된 것이기 때문에
		
		// 세 가지 scope에 저장
		request.setAttribute("request", "request");
		
		HttpSession session = request.getSession();
		session.setAttribute("session", "session");
		
		ServletContext applicaton = getServletContext();
		applicaton.setAttribute("applicaton", "applicaton");
		
		request.getRequestDispatcher("response").forward(request, response);
		// "response" 자리에는 response 서블릿의 매핑값이 들어감
		// forward를 통해서 response 서블릿에 위임했기 때문에 출력은 main이 아닌 response 서블릿이 출력됨
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
