package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.DeptDTO;
import com.service.DeptService;
import com.service.DeptServiceImpl;

// 현재: http://localhost:8090/03_servlet/list 
// 타겟: http://localhost:8090/03_servlet/deptForm.jsp

@WebServlet("/write")
public class DeptWriteServlet extends HttpServlet {
// '저장'버튼 눌렀을 때 서버에 저장하는 서블릿
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String deptno = request.getParameter("deptno"); //getParameter의 리턴타입은 String (정해져있음)
		String dname = request.getParameter("dname");
		String loc = request.getParameter("loc");
		
		// dto에 담고, 서비스로 전달해주기 
		DeptDTO dto = 
				new DeptDTO(Integer.parseInt(deptno), dname, loc);
		
		// 서비스 전달을 위해 서비스연동
		DeptService service = new DeptServiceImpl(); // 서비스 객체 생성
		int n = service.addDept(dto);
		
		// 응답처리
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print("<html><head>");
		out.print("<meta charset=\"UTF-8\">");
		out.print("<title>Insert title here</title>");
		out.print("</head>");
		out.print("<body>");

		out.print("<h1>부서등록 결과</h1>");		 
		if(n==1) {
			out.print("부서등록 성공");
			out.print("<a href='list'>목록보기</a>");
		}else {
			out.print("부서등록 실패");
			out.print("<a href='deptForm.jsp'>부서등록</a>");
		}
		out.print("</body></html>");
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// post 한글처리 ==> 나중에 필터로 구현
		request.setCharacterEncoding("utf-8");
		doGet(request, response); //doget에 의해 get메서드로 넘어감
	}

}
