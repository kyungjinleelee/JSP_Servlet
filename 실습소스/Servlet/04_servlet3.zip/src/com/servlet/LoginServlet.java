package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 유저에게 id값과 passwd값 얻기
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		// DB연동(가정)하고 입력한 userid와 passwd가 confirm -> 인증완료
		// 세션얻기
		HttpSession session = request.getSession();
		// 세션에서 id값 얻기 (getId 메서드)
		System.out.println("세션의 id값: "+ session.getId());
		
		// 세션에 로그인 정보 저장하기
		session.setAttribute("user", userid); // user라는 키 값으로 userid를 저장한다는 뜻
		
		// 로그인 완료 후 응답처리
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print("<html><head>");
		out.print("<meta charset=\"UTF-8\">");
		out.print("<title>로그인 서블릿</title>");
		out.print("</head>");
		out.print("<body>");

		out.print("<h1>로그인 성공</h1>");		 
		out.print("안녕하세요. "+ userid + "님");
		out.print("<a href='mypage'>mypage</a>"); // 링크 누르면 mypage로 이동
		 		// 참고: (링크주소 /mypage는 안됨.) 
 		out.print("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
