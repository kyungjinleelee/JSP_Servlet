package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.BoardDTO;

public class BoardDAO {

	// 전체 목록 
		// 메서드 이름은 BoardMapper.xml 의 id 값(list)
	public List<BoardDTO> list(SqlSession session){ // 지금은 파라미터는 없고 sqlsession 만 받은 것임
		List<BoardDTO> list = session.selectList("BoardMapper.list");
		return list;
	}
	
	// 글 저장
	public int write(SqlSession session, BoardDTO dto) {
		int n = session.insert("BoardMapper.write", dto);
		return n;
		
	}
}
