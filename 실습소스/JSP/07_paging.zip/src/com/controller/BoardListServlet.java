package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.PageDTO;
import com.service.BoardService;
import com.service.BoardServiceImpl;


@WebServlet("/list")
public class BoardListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 1. 클릭할 페이지번호 얻기 (getParameter 이용) 
		String curPage = request.getParameter("curPage");
			// 맨 처음 요청 시 curPage는 null이다. -> 1로 초기화
		if(curPage == null) {
			curPage = "1";
		}
		
		// 2. 서비스 연동
		BoardService service = new BoardServiceImpl();
		PageDTO pageDTO = service.list(Integer.parseInt(curPage));
		
		// 3. scope에 저장 (set 이용)
		request.setAttribute("pageDTO", pageDTO);
		
		// 4. 요청 위임 (forward 밖에 안됨)
		request.getRequestDispatcher("list.jsp").forward(request, response);
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
