package com.dao;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;

import com.dto.BoardDTO;
import com.dto.PageDTO;

public class BoardDAO {

	public PageDTO list(SqlSession session, int curPage) {
		// 1. PageDTO에 4개의 데이터 저장
		PageDTO pageDTO = new PageDTO();
		
		// 시작위치 공식 = (현재page-1) * 페이지 당 보여줄 갯수
		int offset = (curPage-1) * pageDTO.getPerPage();
		//테이블에서 얻을 갯수
		int limit = pageDTO.getPerPage();
		
		// 2. 3개 레코드를 가져오기 및 저장
		List<BoardDTO> list = session.selectList("BoardMapper.list",
												null,
												new RowBounds(offset, limit));
		    // 시작위치랑 보여줄갯수 정해주는 RowBounds 만들기
		    // new RowBounds(시작위치, 보여줄 갯수)
		
		pageDTO.setList(list); // ==> dto에서 가져오고 나면 저장을 꼭 해주자!
		
		// 3. 현재 페이지 번호 저장됨
		pageDTO.setCurPage(curPage); 
		
		// 4. 전체 레코드 갯수 저장
		int totalCount = session.selectOne("BoardMapper.totalCount");
		pageDTO.setTotalCount(totalCount);
		
		return pageDTO;
	}
}
