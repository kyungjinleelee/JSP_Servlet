package com.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.BoardDTO;
import com.service.BoardService;
import com.service.BoardServiceImpl;


@WebServlet("/list")
public class BoardListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 검색 파라미터 얻기 
		String searchName = request.getParameter("searchName");
		String searchValue = request.getParameter("searchValue");
		
		// 위의 2개 값을 서비스 거쳐서 dao에 전달해주기 
		HashMap<String, String> map = new HashMap<>();
		map.put("searchName", searchName);
		map.put("searchValue", searchValue);
		   // 밑의 service.list() 에 map 넣어서 전달해주기!
		
		// 1. BoardService 연동
		BoardService service = new BoardServiceImpl();
		List<BoardDTO> list = service.list(map);
		
		// 이전에는 서블릿에서 응답처리를 했음. ==> list.jsp 위임
		/* list.jsp에서 List<BoardDTO> 보여주기 위해선 
		   List<BoardDTO>를 scope에 저장해야 된다. */
		/*
		 *  request scope (*)
		 *  session scope
		 *  application scope
		 */
		request.setAttribute("boardList", list);
		
	 // 2. 요청 위임 (forward와 redirect 중 forward 써야함)
		request.getRequestDispatcher("list.jsp").forward(request, response);
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
