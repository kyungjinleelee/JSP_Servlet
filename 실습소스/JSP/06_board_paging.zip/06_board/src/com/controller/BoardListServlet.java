package com.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.BoardDTO;
import com.dto.PageDTO;
import com.service.BoardService;
import com.service.BoardServiceImpl;


@WebServlet("/list")
public class BoardListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// list.jsp에서 1 2 3 4 페이지 번호를 클릭할 때 전달된 현재 페이지번호 얻어오기
			// <a href="list?curPage=2>2</a> 이런 모양 
		String curPage = request.getParameter("curPage");
		if(curPage == null) { // 맨 처음 실행한 경우 1로 초기화
			curPage = "1";
		}
		
		// 검색 파라미터 얻기 
		String searchName = request.getParameter("searchName");
		String searchValue = request.getParameter("searchValue");
		
		// 위의 2개 값을 서비스 거쳐서 dao에 전달해주기 
		HashMap<String, String> map = new HashMap<>();
		map.put("searchName", searchName);
		map.put("searchValue", searchValue);
		   // 밑의 service.list() 에 map 넣어서 전달해주기!
		
		// 1. BoardService 연동
		BoardService service = new BoardServiceImpl();
		PageDTO pageDTO = service.list(map, Integer.parseInt(curPage));
		
		// 이전에는 서블릿에서 응답처리를 했음. ==> list.jsp 위임
		/* list.jsp에서 List<BoardDTO> 보여주기 위해선 
		   List<BoardDTO>를 scope에 저장해야 된다. */
		/*
		 *  request scope (*)
		 *  session scope
		 *  application scope
		 */
		request.setAttribute("pageDTO", pageDTO);
		
	 // 2. 요청 위임 (forward와 redirect 중 forward 써야함)
		request.getRequestDispatcher("list.jsp").forward(request, response);
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
