package com.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.MemberDTO;
import com.service.MemberService;
import com.service.MemberServiceImpl;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		HashMap<String, String> map = new HashMap<>();
		map.put("userid", userid);
		map.put("passwd", passwd);
		
		// hashmap을 서비스 거쳐서 dao까지 전달.
		MemberService service = new MemberServiceImpl();
		MemberDTO dto = service.login(map);
		
		String nextPage = null;
		if(dto != null) {
			nextPage = "main";
			
			// 세션 처리
			HttpSession session = request.getSession();
			session.setAttribute("login", dto); // scope에 저장
			
			// session scope에 저장된 login 키의 존재 여부에 따라서 로그인 여부를 알 수 있다.
			// (세션에 login이란 키 값이 있으면 로그인완료 화면을 보여주면 된다는 소리임!) 키 값 없으면 로그인ui 화면 보여주고!
		}else {
			//userid 또는 passwd 틀린 경우
			nextPage = "member/loginFail.jsp";
			
		}
		
		// 요청 위임
		response.sendRedirect(nextPage);
	}

}
