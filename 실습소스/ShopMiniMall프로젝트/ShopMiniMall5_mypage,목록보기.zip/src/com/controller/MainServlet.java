package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.GoodsDTO;
import com.service.GoodsService;
import com.service.GoodsServiceImpl;

@WebServlet("/main")
public class MainServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 상품 목록
		String gCategory=request.getParameter("gCategory");
		if(gCategory == null) { // 맨 처음 요청했을 때는 null임
			gCategory = "top"; // 그래서 top을 디폴트값으로 설정
		}
		GoodsService service = new GoodsServiceImpl();
		List<GoodsDTO> list = service.goodsList(gCategory);
		
		// scope 저장
		request.setAttribute("goodsList", list);
		
		// jsp에 요청 위임 (forward, redirect 상관없음)
		request.getRequestDispatcher("main.jsp").forward(request, response);
	}

}
